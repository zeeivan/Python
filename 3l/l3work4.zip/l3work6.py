def my_func (*args):
    word = input("Введите слова ")
    print(word.title())
    return
my_func()