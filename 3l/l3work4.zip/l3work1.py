
def number_division (a, b):
    return  a / b

print (number_division(int (input('Введите первое число')), int (input('Введите второе число'))))
