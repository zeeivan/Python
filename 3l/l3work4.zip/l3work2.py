def user_info(name, surname, year, city, email, tel):
    print(name, surname, year, city, email, tel)

user_info (name = 'Ivan', surname = 'Mikolenko', year = 28, city = 'Komsomolsk', email = 'mail@mail.ru',
tel = '8999 999 99 99')