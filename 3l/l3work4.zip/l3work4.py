def my_func(x, y):
   return x ** y

print(my_func(2, -4))
