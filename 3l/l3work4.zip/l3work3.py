def my_func (a, b):
    return  a + b

list = sorted([95, 20, 30])

print (my_func(list[1], list[2]))